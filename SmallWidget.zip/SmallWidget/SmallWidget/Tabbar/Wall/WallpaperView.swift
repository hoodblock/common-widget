//
//  WallpaperView.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/5.
//

import SwiftUI
import Kingfisher


struct WallpaperView: View {
    
    let titles: [String] = ["recommend", "artistic", "nature", "minimal", "space"]
    
    @Binding var itemSelected: Int

    @ObservedObject private var wallpaperStore = WallpaperStore.shared

    @State private var itemSelectedImageView: Int = -1

    @State private var showWebView = false

    var body: some View {
        Color.Color_F6F6F6.edgesIgnoringSafeArea(.all).overlay {
            GeometryReader { geometry in
                VStack (alignment: .center, spacing: 0) {
                        if !(geometry.safeAreaInsets.top > 0) {
                            Spacer()
                        }
                        if wallpaperStore.currentWallpaperData.data.count > 0 {
                            ScrollSlidingTabBar(selection: $itemSelected, tabs: wallpaperStore.currentWallpaperData.data.map({ data in
                                data.category.upperFirstLetter
                            }),style: ScrollSlidingTabBar.Style(font: .S_Pro_16(), selectedFont: .S_Pro_18(.medium), activeAccentColor: Color.Color_393672, inactiveAccentColor: Color.Color_A5A6BF, indicatorHeight: 4, borderColor: Color.clear, borderHeight: 0, buttonHInset: ViewLayout.S_W_10(), buttonVInset: ViewLayout.S_H_10()))
                            .padding( [.leading, .trailing], ViewLayout.S_W_10())
                        } else {
                            ScrollSlidingTabBar(selection: $itemSelected, tabs: titles.map({ data in
                                data.upperFirstLetter
                            }), style: ScrollSlidingTabBar.Style(font: .S_Pro_16(), selectedFont: .S_Pro_18(.medium), activeAccentColor: Color.Color_393672, inactiveAccentColor: Color.Color_A5A6BF, indicatorHeight: 4, borderColor: Color.clear, borderHeight: 0, buttonHInset: ViewLayout.S_W_10(), buttonVInset: ViewLayout.S_H_10()))
                                .padding( [.leading, .trailing] , ViewLayout.S_W_10())
                        }
                        Spacer()
                        TabView(selection: $itemSelected) {
                            ForEach(wallpaperStore.currentWallpaperData.data.indices, id: \.self) { index in
                                VStack (alignment: .center, spacing: 0) {
                                    WallpaperItemPage(wallpaperItemData: $wallpaperStore.currentWallpaperData.data[itemSelected], wallpaperPage: $itemSelected)
                                        .onAppear {
                                            wallpaperStore.currentItemWallpaperData = wallpaperStore.currentWallpaperData.data[index]
                                        }
                                }
                            }
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        .listStyle(PlainListStyle())
                }
                .overlay {
                    FloatingDragView {
                        self.showWebView = true
                    }
                }
                .sheet(isPresented: $showWebView) {
                    SafariView(url: URL(string: "https://baidu.com/")!, onDismiss: {
                        print("Safari View dismissed.")
                    })
                }
            }
        }
        .onAppear {
            if wallpaperStore.currentWallpaperData.data.count > 0 && itemSelected == 0 {
                wallpaperStore.currentItemWallpaperData = wallpaperStore.currentWallpaperData.data[0]
            }
        }
    }
}
