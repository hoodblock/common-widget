//
//  LkScreen.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/21.
//

import SwiftUI
import Combine
import Photos


struct LkScreen: View {
    
    @State var isHiddenNative: Bool = true
    @State var isHiddenOverView: Bool = true
    @State var isHiddenDownloadButton: Bool = true
    
    
    @State private var showAlert = false
    @State private var showError = false
    
    enum LoadState {
        case unloaded
        case loading
        case loaded
        case error
    }
    
    @State private var state: LoadState = .unloaded
    
    var imageData: Data = Data()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @Binding var lightModel: Bool

    var body: some View {
        Image(uiImage: (UIImage(data: imageData)!))
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .overlay {
                if !isHiddenOverView {
                    Image("lk_screen")
                        .onTapGesture {
                            withAnimation {
                                isHiddenOverView = true
                                isHiddenNative.toggle()
                                isHiddenDownloadButton.toggle()
                            }
                        }
                }
                if !isHiddenDownloadButton {
                    VStack {
                        Spacer()
                        HStack(alignment: .center) {
                            RoundedRectangle(cornerRadius: ViewLayout.SWidth(10))
                                .fill(Color.Color_8682FF)
                                .frame(height: ViewLayout.SWidth(50))
                                .padding(.horizontal, ViewLayout.SWidth(20))
                                .overlay {
                                    HStack {
                                        Image("down_load")
                                        Text("Download")
                                            .foregroundColor(.white)
                                            .font(.S_Pro_16())
                                    }.onTapGesture {
                                        downloadImage()
                                    }
                                    .alert(isPresented: $showAlert) {
                                        Alert(title: Text("Download Completed"), message: Text("The image has been successfully downloaded."), dismissButton: .default(Text("OK")))
                                    }
                                }
                        }
                        .padding(.bottom, ViewLayout.SWidth(60))
                    }
                }
        }
        .onTapGesture {
            withAnimation {
                isHiddenDownloadButton.toggle()
                isHiddenNative.toggle()
            }
        }
        .ignoresSafeArea(.all)
        .navigationBarVisibility(hidden: $isHiddenNative)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: CustomBackButton(viewBlock: {
            withAnimation(nil) {
                presentationMode.wrappedValue.dismiss()
            }
        }, lightModel: $lightModel))
    }
    
    func downloadImage() {
        if state == .loaded || state  == .loading {
            return
        }
        state = .loading
        PHPhotoLibrary.requestAuthorization { status in
            if status == .authorized {
                DispatchQueue.main.async {
                    if let uiImage = ImageRenderer(content: MnScreen.self.init(isHiddenNative: true, isHiddenOverView: true, lightModel: $lightModel, imageData: self.imageData)).uiImage {
                        if let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                            saveImageToLibrary(data: imageData)
                            showAlert = true
                        }
                    }
                    return
                }
            }
        }
    }
    
    func saveImageToLibrary(data: Data) {
        guard let image = UIImage(data: data) else {
            return
        }
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
}
