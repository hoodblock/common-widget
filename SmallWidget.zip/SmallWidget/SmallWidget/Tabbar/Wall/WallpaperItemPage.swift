//
//  Wallpaper.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/13.
//


import SwiftUI
import Kingfisher

struct WallpaperItemPage: View {
    
    // 分页
    let itemsPerPage = 10 // 每页显示的项目数量
    
    @State private var currentPage = 1
    
    // 绑定外部数据，内部数据来源
    @Binding var wallpaperItemData : WallpaperData
    @Binding var wallpaperPage : Int
    
    @State var isFromTabberShow: Bool = false
    
    @State private var wallpaperStore = WallpaperStore.shared
    
    @State private var isLoading: Bool = false
        
    @State private var isZoomed: Bool = false
    @State private var isShowNavigate: Bool = false
    @State private var currentSelected: Int = 0
    @State private var currentScale: CGFloat = 0.2

    static let itemWidth = ((UIScreen.main.bounds.size.width - ViewLayout.S_W_15() * 2) - ViewLayout.S_W_20()) / 3
    var columnGrid: [ GridItem ] = Array(repeating: .init(.fixed(itemWidth), spacing: ViewLayout.S_W_10()), count : 3)
    
    @State private var isShowNative: Bool = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack (alignment: .center) {
                ScrollView {
                    LazyVGrid(columns: columnGrid, spacing: ViewLayout.S_W_10()) {
                        ForEach(0..<wallpaperStore.currentItemWallpaperData.wallpapers.count, id: \.self) { index in
                            NavigationLink {
                                WallpaperItemPageDetail(imageURL: wallpaperStore.currentItemWallpaperData.wallpapers[index])
                            } label: {
                                contentView(index: index)
                                    .onAppear(perform: {
                                        let framsada = geometry.frame(in: .global)
                                        if index == wallpaperStore.currentItemWallpaperData.wallpapers.count - 1 {
                                            wallpaperStore.fetchMore(wallpaperData: wallpaperStore.currentItemWallpaperData)
                                            withAnimation {
                                                isLoading = true
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                                                    self.isLoading = false
                                                }
                                            }
                                        } else {
                                            isLoading = false
                                        }
                                    })
                            }
                        }
                    }
                    .scrollIndicators(.automatic)
                    .padding([.leading, .trailing, .bottom], ViewLayout.S_W_15())
                    if isLoading {
                        ProgressView()
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding()
                    }
                }
                if isZoomed {
                    NavigationLink (destination: WallpaperItemPageDetail(imageURL: wallpaperStore.currentItemWallpaperData.wallpapers[currentSelected]), isActive: $isShowNavigate) {
                        EmptyView()
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    isShowNavigate = false
                                    isZoomed = false
                                    currentScale = 0.2
                                }
                            }
                    }
                    .hidden()
                }
            }
            .onAppear(perform: {
                currentPage = 1
                wallpaperStore.currentItemWallpaperData = wallpaperItemData
                isLoading = true
            })
        }
    }
    
    func contentView(index: Int) -> some View {
        Rectangle()
            .frame(height: WallpaperItemPage.itemWidth * 1.80)
            .foregroundColor(.white)
            .overlay {
                netImageView(index: index)
            }
            .cornerRadius(ViewLayout.S_W_10(), corners: .allCorners)
            .clipped()
    }
    
    func netImageView(index: Int) -> some View {
        KFImage.url(URL(string: wallpaperStore.currentItemWallpaperData.wallpapers[index]))
            .placeholder {
                ProgressView()
            }
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}




