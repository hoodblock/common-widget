//
//  WallpaperItemPageDetail.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/15.
//

import SwiftUI
import Combine
import Photos
import Kingfisher

struct WallpaperItemPageDetail: View {
    
    var imageURL: String = String()
    
    @State private var cancellable = Set<AnyCancellable>()
    @State private var showAlert = false
    @State private var showError = false
    
    enum LoadState {
        case unloaded
        case loading
        case loaded
        case error
    }
    
    @State var isHiddenNative: Bool = true
    @State var isFirstUpdate: Bool = true

    @State private var state: LoadState = .unloaded
    @State private var imageData: Data = Data()

    @State private var showInsterAds: Bool = true
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State var lightModel: Bool = true
    @State private var showWebView = false

    var body: some View {
        GeometryReader { geo in
            VStack {
                KFImage.url(URL(string: imageURL))
                    .onSuccess({ resultImageProly in
                        if let imageData = resultImageProly.image.jpegData(compressionQuality: 0.8) {
                            self.imageData = imageData
                        }
                        // 加载图像并提取顶部区域的主色调
                        if let topColor = self.getTopColor(from: resultImageProly.image) {
                            // 根据主色调设置电池栏颜色
                            self.setBatteryBarColor(from: topColor)
                        }
                    })
                    .placeholder {
                        ProgressView()
                    }
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                    .overlay(alignment: .center) {
                        if !isHiddenNative {
                            VStack {
                                Spacer(minLength: 0)
                                HStack(spacing: 0) {
                                    NavigationLink {
                                        LkScreen(isHiddenNative: true, isHiddenOverView: false, imageData: self.imageData, lightModel: $lightModel)
                                    } label: {
                                        Image("lock_sc")
                                    }
                                    RoundedRectangle(cornerRadius: ViewLayout.SWidth(10))
                                        .fill(Color.Color_8682FF)
                                        .frame(height: ViewLayout.SWidth(50))
                                        .padding(.horizontal, ViewLayout.SWidth(20))
                                        .overlay {
                                            HStack {
                                                Image("down_load")
                                                Text("Download")
                                                    .foregroundColor(.white)
                                                    .font(.S_Pro_16())
                                            }.onTapGesture {
                                                downloadImage()
                                            }
                                            .alert(isPresented: $showAlert) {
                                                Alert(title: Text("Download Completed"), message: Text("The image has been successfully downloaded."), dismissButton: .default(Text("OK")))
                                            }
                                        }
                                    NavigationLink {
                                        MnScreen(isHiddenNative: true, isHiddenOverView: false, lightModel: $lightModel, imageData: self.imageData)
                                    } label: {
                                        Image("main_sc")
                                    }
                                }
                                .padding(.horizontal, ViewLayout.SWidth(30))
                                .padding(.bottom, ViewLayout.SWidth(60))
                            }
                        }
                    }
            }
            .onAppear {
                if isFirstUpdate {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        withAnimation {
                            self.isHiddenNative = false
                        }
                    }
                }
            }
            .onTapGesture {
                self.isHiddenNative.toggle()
                self.isFirstUpdate = false
            }
            .overlay {
                FloatingDragView {
                    self.showWebView = true
                }
            }
            .navigationBarVisibility(hidden: $isHiddenNative)
            .background(.clear)
            .ignoresSafeArea(.all)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading: CustomBackButton(viewBlock: {
                withAnimation(nil) {
                    UIApplication.shared.statusBarStyle = .darkContent
                    presentationMode.wrappedValue.dismiss()
                }
            }, lightModel: $lightModel))
            .presentInterstitialAd(isPresented: $showInsterAds, adModel: FirebaseNetwork.shared.loadInterstitialAdViewModel().0, showedBlock: {
                showInsterAds = false
            })
            .sheet(isPresented: $showWebView) {
                SafariView(url: URL(string: "https://baidu.com/")!, onDismiss: {
                    print("Safari View dismissed.")
                })
            }
        }
    }
    
    func downloadImage() {
        if state == .loaded || state  == .loading {
            return
        }
        guard URL(string: imageURL) != nil else {
            return
        }
        state = .loading
        PHPhotoLibrary.requestAuthorization { status in
            if status == .authorized {
                DispatchQueue.main.async {
                    if let uiImage = ImageRenderer(content: MnScreen.self.init(isHiddenNative: true, isHiddenOverView: true, lightModel: $lightModel, imageData: imageData)).uiImage {
                        if let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                            saveImageToLibrary(data: imageData)
                            showAlert = true
                        }
                    }
                    return
                }
            }
        }
    }
    
    func saveImageToLibrary(data: Data) {
        guard let image = UIImage(data: data) else {
            return
        }
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
    // 提取顶部区域的主色调
    private func getTopColor(from image: UIImage?) -> UIColor? {
        var cropRect: CGRect = .zero
        guard let cgImage = image?.cgImage else {
            return nil
        }
        let ciImage = CIImage(cgImage: cgImage)
        // 正常
        if image?.cgImage?.width ?? 0 < 1000 {
            cropRect = CGRect(x: 0, y: 0, width: image?.cgImage?.width ?? 300, height: image?.cgImage?.height ?? 50)
        } else { // 放大了三倍
            cropRect = CGRect(x: 0, y: 0, width: image?.cgImage?.width ?? 500, height: image?.cgImage?.height ?? 100)
        }
        // 将图像裁剪为指定的长方形区域
        let croppedImage = ciImage.cropped(to: cropRect)
        // 计算裁剪区域的平均颜色
        return croppedImage.averageColor()
   }

    // 根据主色调设置电池栏颜色
    private func setBatteryBarColor(from color: UIColor) {
        let uiColor = color
        let ciColor = CIColor(color: uiColor)
        if ciColor.red * 0.299 + ciColor.green * 0.587 + ciColor.blue * 0.114 > 0.5 {
            // 浅色背景下设置电池栏颜色为黑色
            lightModel = false
        } else {
            // 深色背景下设置电池栏颜色为白色
            lightModel = true
        }
        UIApplication.shared.statusBarStyle = lightModel ? .lightContent : .darkContent
    }
}


extension CIImage {
    func averageColor() -> UIColor? {
        guard let outputImage = CIFilter(name: "CIAreaAverage", parameters: [kCIInputImageKey: self])?.outputImage else { return nil }
        var bitmap = [UInt8](repeating: 0, count: 4)
        let context = CIContext(options: nil)
        context.render(outputImage, toBitmap: &bitmap, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: CIFormat.RGBA8, colorSpace: nil)
        return UIColor(red: CGFloat(bitmap[0]) / 255.0, green: CGFloat(bitmap[1]) / 255.0, blue: CGFloat(bitmap[2]) / 255.0, alpha: 1)
    }
}
