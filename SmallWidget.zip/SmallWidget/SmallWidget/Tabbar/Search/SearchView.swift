//
//  SearchView.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/6.
//

import SwiftUI

struct SearchView: View {
    
    @State private var inputText: String = ""
    let hots: [String] = ["My battery", "Calendar", "Weather", "Clock"]
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        VStack {
            HStack {
                HStack {
                    Image("widgets_search")
                        .padding(.leading, 13)
                    TextField("", text: $inputText,prompt: Text("Please enter a keyword").font(.S_Pro_12()).foregroundColor(Color.Color_C2C3CF))
                        .foregroundColor(Color.Color_393672)
                        .font(.S_Pro_12())
                        .overlay {
                            HStack {
                                Spacer(minLength: 0)
                                if !inputText.isEmpty {
                                    Button {
                                        inputText = ""
                                    } label: {
                                        Image("clean_mode")
                                            .frame(width: 20, height: 20)
                                            .padding(.trailing, 10)
                                    }
                                }
                                
                            }
                        }
                        
                    
                }
                .frame(height: 40)
                .background(Color.white)
                .cornerRadius(10)
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Text("Cancel")
                        .font(.S_Pro_16())
                        .foregroundColor(Color.Color_A5A6BF)
                }

                
            }
            .padding([.leading, .trailing], 20)
            
            VStack {
                List {
                    Text("Popular Widgets")
                        .font(.S_Pro_16())
                        .foregroundColor(Color.Color_393672)
                        .listRowBackground(Color.Color_F6F6F6)
                        .listRowInsets(EdgeInsets())
                    ForEach(hots.indices, id:\.self) { index in
                        HStack(spacing: 0) {
                            Text("\(index+1)." + hots[index])
                                .font(.S_Pro_16())
                                .foregroundColor(Color.Color_A5A6BF)
                            Image("hot_\(index)")
                                .padding(.leading, 9)
                        }
                        .listRowBackground(Color.Color_F6F6F6)
                        .listRowInsets(EdgeInsets())
                        .listRowSeparator(.hidden)
                    }
                }
                .listStyle(.plain)
                .frame(height: 230)
                .padding([.leading, .trailing], 20)
                HStack {
                    Text("Recommend")
                        .font(.S_Pro_16())
                        .foregroundColor(Color.Color_393672)
                        .padding(.leading, 20)
                    Spacer(minLength: 0)
                }
                
                ScrollView(.horizontal){
                    LazyHStack{
                        Text("ssss")
                        
                        Text("xxxx")
                    }
                    
                }
                Spacer(minLength: 0)
            }
            
            
        }
        .navigationBarHidden(true)
       
        .background(Color.Color_F6F6F6)
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
