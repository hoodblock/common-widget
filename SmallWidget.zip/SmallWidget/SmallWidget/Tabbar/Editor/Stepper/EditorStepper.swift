//
//  EditorStepper.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/11.
//

import SwiftUI

struct EditorStepper: View {
    
    @ObservedObject var config: JRWidgetConfigure  // 观察属性，及时修改
    
    @State private var showing = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text("Target Steps")
                    .foregroundColor(Color.Color_393672)
                    .font(.S_Pro_14())
                Spacer(minLength: 0)
                Label(config.itemConfig_1.text, image: "wall_arrow")
                    .labelStyle(WLabelBStyle())
                    .fullScreenCover(isPresented: $showing) {
                        StepperPickerView(config: config)
                            .background(BackgroundClearView())
                    }
                    .onTapGesture {
                        showing.toggle()
                    }
            }
            .padding(.bottom, 6)
            Divider()
                .overlay(Color.dividerBkg)
              
        }
    }
}

struct EditorStepper_Previews: PreviewProvider {
    static var previews: some View {
        EditorStepper(config: JRWidgetConfigure())
    }
}
