//
//  FeedbackView.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/14.
//

import SwiftUI

struct FeedbackView: View {
        
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    @State private var inputText = ""
    @State private var emailText = ""
    @State var lightModel: Bool = false

    var body: some View {
        VStack(spacing: 18){
            TextField("", text: $inputText, prompt: Text("Please write down your question or suggestion, and we will reply to you as soon as possible."), axis: .vertical)
                    .lineLimit(4...10)
                    .frame(height: 110)
                    .padding()
            
            .background(.white)
            .padding(.top, 10)
            
            TextField("", text: $emailText, prompt: Text("Your email or phone number"))
                .frame(height: 48)
                .padding(.horizontal, 22)
                .background(.white)
            
            Spacer(minLength: 0)
            Rectangle()
                //sliderIndicator
                .fill((inputText.count > 0 && emailText.count > 0) ? Color.Color_8682FF : Color.buttonUnavailable)
                .frame(width: 195, height: 40)
                .cornerRadius(10)
                .overlay {
                Text("Submit")
                        .foregroundColor((inputText.count > 0 && emailText.count > 0) ?  Color.white : Color.buttonTextUn)
            }
                .padding(.bottom, 55)
            
        }
        .frame(maxWidth:.infinity, maxHeight: .infinity)
        .padding(.horizontal, 20)
        .background(Color.Color_F6F6F6)
        .navigationTitle("Feedback")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: CustomBackButton(viewBlock: {
            withAnimation(nil) {
                presentationMode.wrappedValue.dismiss()
            }
        }, lightModel: $lightModel))
        .toolbarBackground(.white, for: .navigationBar)
    }
}

struct FeedbackView_Previews: PreviewProvider {
    static var previews: some View {
        FeedbackView()
    }
}
