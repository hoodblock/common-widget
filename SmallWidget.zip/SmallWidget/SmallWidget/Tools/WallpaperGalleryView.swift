//
//  WallpaperGalleryView.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/14.
//

import SwiftUI

struct WallpaperGalleryView: View {
    
    @Environment(\.dismiss) var dismiss
    
    let colums = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        Color.black.opacity(0.2).edgesIgnoringSafeArea(.all)
            .overlay {
                VStack {
                    Spacer(minLength: 0)
                        .frame(height: 258)
                    VStack (spacing: 0){
                        HStack{
                            Spacer(minLength: 0)
                            Image("wallpaper_close")
                                .padding(.trailing, 14)
                                .onTapGesture {
                                    dismiss()
                                }
                        }.padding(.top, 14)
                        .overlay {
                            Text("Wallpaper Gallery")
                                .padding(.top, 6)
                        }.padding(.bottom, 20)
                       
                        ScrollView{
                            LazyVGrid(columns: colums) {
                                ForEach(0..<20) { _ in
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color.blue)
                                        .aspectRatio(0.754, contentMode: .fit)
                                }
                            }
                            .padding(.horizontal, 20)
                        }
                    }
                    .background(Color.white)
                    .cornerRadius(20, corners: [.topLeft, .topRight])
                    .edgesIgnoringSafeArea(.bottom)
                    
                    
                }
            }
    }
}

struct WallpaperGalleryView_Previews: PreviewProvider {
    static var previews: some View {
        WallpaperGalleryView()
    }
}
