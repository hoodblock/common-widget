//
//  StepperPickerView.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/14.
//

import SwiftUI

struct StepperPickerView: View {
    
    @Environment(\.dismiss) var dismiss
    
    @ObservedObject var config: JRWidgetConfigure  // 观察属性，及时修改

    

    init(config: JRWidgetConfigure) {
        self.config = config
    }
    
    let data = [
                 "2000", "3000", "4000", "5000", "6000", "7000", "8000", "9000", "10000",
                 "11000", "12000", "13000", "14000", "15000", "16000", "17000", "18000", "19000", "20000",
                 "21000", "22000", "23000", "24000", "25000", "26000", "27000", "28000", "29000", "30000",
                 "31000", "32000", "33000", "34000", "35000", "36000", "37000", "38000", "39000", "40000",
                 "41000", "42000", "43000", "44000", "45000", "46000", "47000", "48000", "49000", "50000",
                 "51000", "52000", "53000", "54000", "55000", "56000", "57000", "58000", "59000", "60000",
            ]
    
    var body: some View {
        
        Color.black.opacity(0.3).edgesIgnoringSafeArea(.all)
            .overlay {
                VStack(spacing: 0) {
                    Spacer(minLength: 0)
                    HStack {
                        Spacer(minLength: 0)
                        Image("picker_cancel")
                            .padding(.trailing, 12)
                            .padding(.top, 12)
                            .onTapGesture {
                                dismiss()
                            }
                    }.background(Color.white)
                        .cornerRadius(10, corners: [.topLeft, .topRight])
                    
                    Picker("Cyclle Period", selection: self.$config.itemConfig_1.text) {
                        ForEach(0..<data.count, id:\.self) { row in
                            Text(data[row])
                                .tag(data[row])
                                .foregroundColor(Color.pickerText)
                                .font(.S_Pro_23())
                        }
                    }
                    .pickerStyle(.wheel)
                    .background(Color.white)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.Color_8682FF)
                        .frame(height:50)
                        .padding(.horizontal, 20)
                        .background(Color.white)
                        .overlay {
                            Text("Confirm Steps")
                                .foregroundColor(Color.white)
                        }
                        .onTapGesture {
//                            config.itemConfig_1.text = current
                            config.backgroundColor = config.backgroundColor
                            dismiss()
                        }
                }
                
                
                
            }
    }
    
}
