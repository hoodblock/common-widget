//
//  NetworkService.swift
//  SmallWidget
//
//  Created by Thomas on 2023/6/20.
//
import Foundation
import Combine
import HandyJSON

class NetworkService {
    
    static let shared = NetworkService()
    private init() {
        
    }

    func getWallpapers() -> AnyPublisher<(Bool, [WallpaperData]?), Never> {
        guard let url = URL(string: "https://api.openget.top") else {
            return Just((false, nil)).eraseToAnyPublisher()
        }
        let parameters = [
            "userId" : DeviceInfoUtil.getIdentifierID(),
            "appId": DeviceInfoUtil.getappBundleID(),
            "appver": DeviceInfoUtil.getappSVersion(),
            "sysVer": DeviceInfoUtil.getDevicesystemVersion(),
            "countryCode": "US"
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
      
        if let body = try? JSONSerialization.data(withJSONObject: parameters){
            // 先压缩
            if let zipData = try? body.gzipped(level: .bestCompression) {
                // 加密
               let encrypString =  EncryptUtil.encryptionData(zipData)
                let requestData = Data(bytes: encrypString, count: zipData.count)
                request.httpBody = requestData
            }
        }
        
        return URLSession.shared.dataTaskPublisher(for: request)
            .map { data, reponse in
                do {
                    let sourceData = EncryptUtil.dencryptionData(data)
                    if let source =  try? sourceData.gunzipped() {
                        let jsonString = String(data: source, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
                        let dataResp = Response.deserialize(from: jsonString)!
                        return (dataResp.status == 200, dataResp.data)
                    } else{
                        return (false, nil)
                    }
                }
            }
            .replaceError(with: (false, nil))
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
    
    
    func getMoreWallpaper(category: String, index: Int) ->AnyPublisher<(Bool, WallpaperData?), Never> {
        guard let url = URL(string: "https://api.opeet.top/mby=\(category)&index=\(index)&size=10") else {
            return Just((false, nil)).eraseToAnyPublisher()
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        return URLSession.shared.dataTaskPublisher(for: request)
            .map { data, reponse in
                do {
                    let sourceData = EncryptUtil.dencryptionData(data)
                    if let source = try? sourceData.gunzipped() {
                        let jsonString = String(data: source, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
                        let dataResp = CategoryResponse.deserialize(from: jsonString)!
                        return (dataResp.status == 200, dataResp.data)
                    } else {
                        return (false, nil)
                    }
                }
            }
            .replaceError(with: (false, nil))
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}


class Response: HandyJSON {
    var status: Int = 0
    var isLoadMore: Bool = false
    var data: [WallpaperData] = []
    required init() {
    }
}

class CategoryResponse: HandyJSON {
     var status: Int = 0
     var data: WallpaperData = WallpaperData()
    required init() {
    }
}
    
class WallpaperData: HandyJSON {
    var hasMore: Bool = false
    var wallpapers: [String] = []
    var lastIndex: Int = 0
    var category: String = String()
    required init() {
    }
}

// 照片墙本地数据
class WallpaperStore: ObservableObject {
    
    static let shared = WallpaperStore()
    
    @Published var currentWallpaperData: Response = Response()
    
    @Published var currentItemWallpaperData: WallpaperData = WallpaperData()
    
    @Published var userId: String = DeviceInfoUtil.getIdentifierID()

    @Published var isValid: Bool = false
        
    private var cancellables = Set<AnyCancellable>()
    
    @Published var lastIndex: Int = 0

    public enum PagingState {
        case loading
        case loaded
        case error
    }

    private var state: PagingState = .loaded

    private var canLoadMore: Bool { currentItemWallpaperData.hasMore }

    private lazy var isListAvailablePublisher: AnyPublisher<(Bool, [WallpaperData]?), Never> = {
        $userId
            .flatMap { userId -> AnyPublisher<(Bool, [WallpaperData]?), Never> in
                NetworkService.shared.getWallpapers()
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }()
    
    init() {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            loadWallpaparDataFromFile()
            isListAvailablePublisher
                .sink { [weak self] isValid, list in
                    self?.isValid = isValid
                    if list?.count ?? 0 > 0 {
                        if self?.currentWallpaperData.data.count == 0 {
                            let respont = Response()
                            respont.data = list!
                            self?.currentWallpaperData = respont
                            self?.saveWallpaperDataToFile(wallpaperData: (self?.currentWallpaperData)!)
                        } else {
                            for wallItem in list! {
                                self?.saveWallpaperItemDataToFile(category: wallItem.category, wallpaperData: wallItem, updateType: true)
                            }
                        }
                    }
                }
                .store(in: &cancellables)
        }
    }
    
    func updateData() {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            if self.currentWallpaperData.data.count == 0 {
                loadWallpaparDataFromFile()
                isListAvailablePublisher
                    .sink { [weak self] isValid, list in
                        self?.isValid = isValid
                        if list?.count ?? 0 > 0 {
                            if self?.currentWallpaperData.data.count == 0 {
                                let respont = Response()
                                respont.data = list!
                                DispatchQueue.main.async {
                                    self?.currentWallpaperData = respont
                                    self?.currentItemWallpaperData = respont.data[0]
                                }
                                self?.saveWallpaperDataToFile(wallpaperData: (self?.currentWallpaperData)!)
                            } else {
                                for wallItem in list! {
                                    self?.saveWallpaperItemDataToFile(category: wallItem.category, wallpaperData: wallItem, updateType: true)
                                }
                            }
                        }
                    }
                    .store(in: &cancellables)
            }
        }
    }
    
    // 保存全部数据
    func saveWallpaperDataToFile(wallpaperData: Response) {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            let fileURL = documentsDirectory?.appendingPathComponent(String(DeviceInfoUtil.getappBundleID() + "dateil"))
            DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).sync {
                let wallpaperData = wallpaperData.toJSONString()!.data(using: String.Encoding.utf8, allowLossyConversion: false)
                try? wallpaperData?.write(to: fileURL!)
            }
        }
    }
    
    // 保存某一个分类的数据。有加载时机,分页
    func saveWallpaperItemDataToFile(category: String, wallpaperData: WallpaperData, updateType: Bool) {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            let fileURL = documentsDirectory?.appendingPathComponent(String(DeviceInfoUtil.getappBundleID() + "dateil"))
            if (fileURL != nil) {
                for wallpaperItem in self.currentWallpaperData.data {
                    if wallpaperItem.category == wallpaperData.category {
                        if updateType {
                            if !wallpaperItem.wallpapers.contains(wallpaperData.wallpapers) {
                                wallpaperItem.wallpapers = wallpaperData.wallpapers + wallpaperItem.wallpapers
                                if wallpaperItem.category == self.currentItemWallpaperData.category {
                                    self.currentItemWallpaperData = wallpaperItem
                                }
                                DispatchQueue.global().async {
                                    let wallpaperData = self.currentWallpaperData.toJSONString()!.data(using: String.Encoding.utf8, allowLossyConversion: false)
                                    try? wallpaperData?.write(to: fileURL!)
                                }
                            }
                        } else {
                            wallpaperItem.wallpapers = wallpaperItem.wallpapers + wallpaperData.wallpapers
                            if wallpaperItem.category == self.currentItemWallpaperData.category {
                                self.currentItemWallpaperData = wallpaperItem
                            }
                            DispatchQueue.global().async {
                                let wallpaperData = self.currentWallpaperData.toJSONString()!.data(using: String.Encoding.utf8, allowLossyConversion: false)
                                try? wallpaperData?.write(to: fileURL!)
                            }
                        }
                      
                    }
                }
            }
            let respont = self.currentWallpaperData
            self.currentWallpaperData = respont
        }
    }
    
    // 保存某一个分类的数据，无加载时机，全部数据
    func saveWallpaperItemDataLocal(category: String, wallpaperData: WallpaperData) {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            let fileURL = documentsDirectory?.appendingPathComponent(String(DeviceInfoUtil.getappBundleID() + "dateil"))
            DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).sync {
                let wallpaperData = self.currentWallpaperData.toJSONString()!.data(using: String.Encoding.utf8, allowLossyConversion: false)
                try? wallpaperData?.write(to: fileURL!)
            }
        }
    }
    
    // 获取数据
    func loadWallpaparDataFromFile() {
        DispatchQueue(label: DeviceInfoUtil.getappBundleID(), attributes: .concurrent).asyncAndWait {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            let fileURL = documentsDirectory?.appendingPathComponent(String(DeviceInfoUtil.getappBundleID() + "dateil"))
            if let data = try? Data(contentsOf: fileURL!) {
                let jsonString = String(data: data, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
                self.currentWallpaperData = Response.deserialize(from: jsonString) ?? Response()
            }
        }
    }
    
    private lazy var isMoreCategoryPublisher: AnyPublisher<(Bool, WallpaperData?), Never> = {
        $lastIndex
            .flatMap{ lastIndex -> AnyPublisher<(Bool, WallpaperData?), Never> in
                NetworkService.shared.getMoreWallpaper(category: (self.currentItemWallpaperData.category), index: self.currentItemWallpaperData.wallpapers.count)
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
        
    }()
    
    func fetchMore(wallpaperData: WallpaperData) {
        self.currentItemWallpaperData = wallpaperData
        if !canLoadMore {
            return
        }
        if state == .loading {
            return
        }
        state = .loading
        lastIndex = wallpaperData.lastIndex
        isMoreCategoryPublisher
            .sink { [weak self] isValid, data in
                self?.isValid = isValid
                if data != nil {
                    if !self!.currentItemWallpaperData.wallpapers.contains(data!.wallpapers) {
                        DispatchQueue.main.async {
                            self?.currentItemWallpaperData.wallpapers.append(contentsOf: data!.wallpapers)
                            self?.currentItemWallpaperData.lastIndex = data!.lastIndex
                            for index in 0..<self!.currentWallpaperData.data.count {
                                if self!.currentWallpaperData.data[index].category == self?.currentItemWallpaperData.category {
                                    self!.currentWallpaperData.data[index] = self!.currentItemWallpaperData
                                }
                            }
                        }
                        self?.saveWallpaperItemDataLocal(category: self!.currentItemWallpaperData.category, wallpaperData: self!.currentItemWallpaperData)
                    }
                }
                self?.state = .loaded
            }
            .store(in: &cancellables)
    }
}
