//
//  AppImage.swift
//  SmallWidget
//
//  Created by Thomas on 2023/11/2.
//

import Foundation
import SwiftUI


extension Image {
    
 
    
}
